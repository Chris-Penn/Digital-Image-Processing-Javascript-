This program converts an array of RGB values into a histogram, where values can be compared by frequency.

To use the program, input the terminal command: node index.js> out.csv

once in csv format, image data can be produced, in this case using Microsoft Excel.

Images 1txt.png, 2txt.png, and 3txt.png display plots of all red, green, and blue pixels' values.